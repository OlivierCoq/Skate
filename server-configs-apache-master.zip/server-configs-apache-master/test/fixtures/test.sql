create table test (
     id integer,
     description varchar(50),
     primary key (field1)
);
