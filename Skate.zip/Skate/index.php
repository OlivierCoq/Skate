<?php
/* 
 * @package Skate-Theme
*/    
get_header(); ?>   
 









<!--Footer-->
<?php
get_footer();
?>      
