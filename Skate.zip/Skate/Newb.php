<?php
/* 
 *Template Name: Newbie
*/    
get_header(); ?>   
 
 




<!--Footer-->
<?php
get_footer();
?>      
