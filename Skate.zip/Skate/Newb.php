<?php
/* 
 * @package Newbie
*/    
get_header(); ?>   
 





<!--Footer-->
<?php
get_footer();
?>      
