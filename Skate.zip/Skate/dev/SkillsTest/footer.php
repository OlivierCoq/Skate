<?php
/**
 *Hello 24 Data Team! Olivier here. Here's a typical footer.php file, written ...The way WordPress likes it, and from scratch.
 *
 */

?>
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>

	</div><!-- #content -->

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
